﻿namespace konsola
{
    public class Metody
    {
        /************************************************
             klasa: Metody
             opis: klasa zawiera metody potrzebne do dzialania programu
             metody: LiczSamogloski - zwraca liczbe samoglosek w podanym parametrze
                     UsunPowtorzenia - zwraca podany parametr bez powtarzajacych sie po sobie znakow
             autor: 000000000001
        ************************************************/

        public static int LiczSamogloski(string tekst)
        {
            if (string.IsNullOrEmpty(tekst))
            {
                return 0;
            }

            int wynik = 0;
            string samogloski = "aąeęiouóyAĄEĘIOUÓY";

            foreach (char znak in tekst)
            {
                if (samogloski.Contains(znak))
                {
                    wynik++;
                }
            }

            return wynik;
        }

        public static string UsunPowtorzenia(string tekst)
        {
            if (!string.IsNullOrEmpty(tekst))
            {
                string wynik = "";
                wynik += tekst[0];
                for (int i = 1; i < tekst.Length; i++)
                {
                    if (!(tekst[i-1] == tekst[i]))
                    {
                        wynik += tekst[i];
                    }
                }
                return wynik;
            }
            else
            {
                return string.Empty;
            }
        }
    }

}
