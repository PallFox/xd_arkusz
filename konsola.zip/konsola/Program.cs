﻿namespace konsola
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Podaj tekst:");
            string input = Console.ReadLine();



            int data = Metody.LiczSamogloski(input);
            Console.WriteLine(data);

            string removed = Metody.UsunPowtorzenia(input);
            Console.WriteLine(removed);

        }
    }
}
